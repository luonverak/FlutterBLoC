class RepoResponse<T> {
  late T record;
  RepoResponse({
    required this.record,
  });
}
