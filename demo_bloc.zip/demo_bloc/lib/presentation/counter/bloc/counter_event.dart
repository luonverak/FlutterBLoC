class CounterEvent {}

class CounterEventIncrease extends CounterEvent {}

class CounterEvenDecrease extends CounterEvent {}
