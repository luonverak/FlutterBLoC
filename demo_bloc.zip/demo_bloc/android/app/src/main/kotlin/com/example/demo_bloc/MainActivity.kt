package com.example.demo_bloc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
